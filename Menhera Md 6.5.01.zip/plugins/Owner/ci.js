let handler = async (m, { hanz }) => {
  if (!m.quoted) throw "repy pesan saluran";
  try {
    let id = (await m.getQuotedObj()).msg.contextInfo
      .forwardedNewsletterMessageInfo;
    let teks = "Channel Name:" + " `" + `${id.newsletterName}` + "`\n";
    teks += "Channel Id:" + " `" + `${id.newsletterJid}` + "`";
    await hanz.reply(m.chat, teks.trim(), m);
  } catch (e) {
    Log(e);
    throw "Harus chat dari channel";
  }
};
handler.help = handler.command = ["ci","idch"];
handler.tags = ["main"];
handler.private = true
module.exports = handler;