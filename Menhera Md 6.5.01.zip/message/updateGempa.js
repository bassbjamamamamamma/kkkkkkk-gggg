
// File: function.js
const fs = require('fs-extra');
const axios = require("axios");
const moment = require("moment-timezone");
const Jimp = require('jimp');



        // Cek apakah ada info gempa sebelumnya dan apakah ada perubahan lokasi atau waktu
       
          

module.exports = { updateGempa };
